docker build -t nbase N-BASE 
