#include <stdio.h>
#include <sys/types.h>
#include <stdint.h>

int main(int argc,char **argv)
{
    int32_t max   = 2147483647 ;
    int32_t start = 2147473647 ;

    int32_t q ;
    int32_t a = 1 ;

    q = max/2 ;


    for(int i=0;i<q;i++)
    {
        a += 2 ;
    }

    printf("max %d ,result %d\n",max,a) ;
    
}
