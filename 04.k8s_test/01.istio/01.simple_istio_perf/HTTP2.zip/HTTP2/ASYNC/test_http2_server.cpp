#include <stdio.h>

#include <mutex>
#include <vector>
#include <sys/epoll.h>
#include "CNDFThread.hpp"
#include "CNDFHttp2Listener.hpp"
#include "CNDFHttp2Response.hpp"
#include "NDFHttp2Option.hpp"
#include "NDFServiceLog.hpp"

NDF_ST_HTTP2_OPTIONS G_HTTP2_OPTION ;

int  G_OPT_PORT         = 0 ;
bool G_OPT_VERBOSE      = false ;
bool G_OPT_UPGRADE      = false ;
bool G_OPT_EXTERN_EVENT = false ;

void test_callback(int _event,int32_t _streamId,int _error,void *_conn,void *_userData)
{
    //printf("CALLBACK %d %d %d %p %s\n",_event,_streamId,_error,_conn,(char *)_userData) ;
}

class CRecv : public CNDFThread
{
    private :
        CNDFHttp2Response *res_ ;

        void Initial(void) {} ;
        void Final  (void) {} ;
        void Run    (void) ;

    public :
        CRecv() {} ;
        ~CRecv() {} ;

        void  Set(CNDFHttp2Response *_res) { res_ = _res ; }
};

class CSend : public CNDFThread
{
    private :
        CNDFHttp2Response *res_ ;

        void Initial(void) {} ;
        void Final  (void) {} ;
        void Run    (void) ;

    public :
        CSend() {} ;
        ~CSend() {} ;

        void  Set(CNDFHttp2Response *_res) { res_ = _res ; }
};

std::vector<std::pair<int32_t,int>> requestList_ ;
std::mutex                          mutex_ ;

void CRecv::
Run(void)
{
    NDF_ST_HTTP2_REQUEST_RECV  req ;
    int                        nRecv = 0 ;
    char                       temp[10] ;
    int                        rv ;
    int                        v ;

    for(;;)
    {
        if ((rv = res_->Request(&req)) == -1 ) // error
        {
            break ;
        }
        else if ( rv == 0 )                         // no request
        {
            // do not sleep..
            continue ;
        }
        else
        {
            nRecv++ ;

            if (( nRecv % 200000) == 0)
            {
                continue ; // test for client request timeout
            }

            sprintf(temp,"%8.8s",req.data_) ;
            v = atoi(temp) ;

            mutex_.lock() ;
            requestList_.push_back(std::make_pair(req.streamId_,v)) ;
            mutex_.unlock() ;

            if ( G_OPT_VERBOSE == true )
            {
                printf("Recv Request...StreamId=%d value[%4d:%8.8s]\n",req.streamId_,(int)req.size_,req.data_) ;
                for(auto it = req.hdr_->begin();it != req.hdr_->end();it++)
                {
                    printf("\tHeader-info[%s-%s]\n",(*it).first.c_str(),(*it).second.c_str()) ;                
                }
            }
            else
            {
                if ((nRecv % 1000) == 0 )
                {
                    printf("%d request...value[%4d:%8.8s]\n",nRecv,(int)req.size_,req.data_) ;
                }
            }
        }
    }

    printf("RECV=%d\n",nRecv) ;
}

void CSend::
Run(void)
{
    NDF_ST_HTTP2_RESPONSE res ;
    int32_t               stream_id ;
    int                   ret ;
    int                   v; 

    res.payload_.data_ = (char *)malloc(4096) ;

    for(;;)
    {
        if ( res_->GetState() == NDF_HTTP2_CONN_STATE_CLOSE ) break ;

        mutex_.lock() ;
        auto it =  requestList_.begin() ;
        if ( it == requestList_.end())
        {
            mutex_.unlock() ;
            usleep(100) ;
            continue ;
        }
        stream_id = (*it).first ;
        v         = (*it).second ;
        requestList_.erase(it) ;
        mutex_.unlock() ;

        res.streamId_ = stream_id ;
        strcpy(res.rs_,"200") ;
        sprintf(res.payload_.data_,"%08d",v) ;
        res.payload_.size_ = G_HTTP2_OPTION.nMaxPayloadSize_ ;

        for(int i=0;i<10;i++) 
        {
            ret = res_->Response(&res,false) ;
            switch(ret)
            {
                case NDF_HTTP2_RESPONSE_QUEUE_FULL : 
                    printf("queue full\n") ;
                    usleep(100) ;
                    break ;
                case NDF_HTTP2_RESPONSE_CONN_CLOSE : 
                    printf("error\n") ;
                    break ;
            }
            if ( ret == NDF_HTTP2_RESPONSE_QUEUE_FULL ) continue ;
            break ;
        }
        if ( ret != NDF_HTTP2_RESPONSE_SUCCESS ) 
        {
            break ;
        }
    }

    free(res.payload_.data_) ;
}

bool doTest(void)
{
    CNDFHttp2Listener  listener ;
    CNDFHttp2Response *res ;
    int                ret ;
    CSend              s ;
    CRecv              r ;

    memset(&G_HTTP2_OPTION,0x00,sizeof(NDF_ST_HTTP2_OPTIONS)) ;
    G_HTTP2_OPTION.nMaxPayloadSize_ = 4096 ;
    G_HTTP2_OPTION.nMaxConcurrentStream_ = 50 ; // for too many request response test...
    //G_HTTP2_OPTION.nMaxConcurrentStream_ = 1000 ;

    if ( G_OPT_UPGRADE == false )
    {
        if ( listener.Initialize(AF_INET,G_OPT_PORT,&G_HTTP2_OPTION,G_OPT_EXTERN_EVENT,
                 (char *)"./server.key",(char *)"./server.crt",0) == false )
        {
            return false ;
        }
    }
    else
    {
        if ( listener.Initialize(AF_INET,G_OPT_PORT,&G_HTTP2_OPTION,G_OPT_EXTERN_EVENT) == false )
        {
            return false ;
        }

    }
    if ( G_OPT_EXTERN_EVENT == true )
    {
        //return  doTestEvent(listener.GetSocket(),G_OPT_PORT,G_OPT_UPGRADE,listener.GetSSLCTX()) ;
        return false ;
    }
    else
    { 
        for(;;)
        {
            ret = listener.Accept(&res,1000) ;
            if ( ret == -1 ) // 1 sec waiting
            {
                return false ;
            }
            else if ( ret == 0 ) 
            {
                printf("no event...\n") ;
                continue ;
            }
            else break ;
        }

        printf("client connected...\n") ;

        res->SetUserCallback(test_callback,(void *)"callback testing!") ;

        r.Set(res) ;
        s.Set(res) ;

        s.Execute() ;
        r.Execute() ;

        for(;;)
        {
            if ( r.GetStatus() == CNDFThread::NDF_THREAD_TERMINATE &&
                 s.GetStatus() == CNDFThread::NDF_THREAD_TERMINATE )
            {
                break ;
            }
            sleep(1) ;
        }

        res->Disconnect() ;

        return true ;
    }
}

void Help(char *_name)
{
    fprintf(stderr,"Invalid Arguments...\n") ;
    fprintf(stderr,"\t./%s -p port [-u] [-v] [-c test-count]\n",_name) ;
    fprintf(stderr,"\t -p port  : host listening port\n") ;
    fprintf(stderr,"\t -u       : http/1/1 upgrade connect mode\n") ;
    fprintf(stderr,"\t -e       : external event dispath mode\n") ;
    fprintf(stderr,"\t -v       : verbose mode\n") ;
    fprintf(stderr,"examples)\n\t%s -p 8088 -u -v\n",_name) ;
}

bool ParseArg(int _argc,char **_argv)
{
    int  mode = -1 ;
    int  opt ;

    while((opt = getopt(_argc,_argv, "h:p:c:uve")) != -1)
    {
        switch(opt)
        {
            case 'p':
                mode = 0 ;
                if ( !optarg ) mode = -1 ; else G_OPT_PORT = atoi(optarg) ;
                break ;
            case 'e':
                G_OPT_EXTERN_EVENT = true ;
                break ;
            case 'u':
                G_OPT_UPGRADE = true ;
                break ;
            case 'v':
                G_OPT_VERBOSE = true ;
                break ;
            default :
                mode = -1 ;
                break ;
        }
    }

    if ( mode == -1 || G_OPT_PORT == 0 )
    {
        Help(_argv[0]) ;
        return false ;
    }

    return true ;
}

int main(int argc,char **argv)
{
    bool result ;

    if ( ParseArg(argc,argv) == false ) exit(0) ;

    NDF_OPEN_SERVICE_LOG(15) ;

    NDF_HTTP2_INIT() ;

    result = doTest() ;

    NDF_CLOSE_SERVICE_LOG() ;

    if ( result == true ) exit(0); else exit(1) ;
}
