#include "NDFCommonOpenSSL.hpp"
#include "CNDFThread.hpp"
#include "CNDFHttp2Request.hpp"
#include "NDFHttp2Option.hpp"
#include "NDFServiceLog.hpp"

NDF_ST_HTTP2_OPTIONS G_HTTP2_OPTION ;

char G_OPT_HOST[32] ;
int  G_OPT_PORT         = 0 ;
bool G_OPT_VERBOSE      = false ;
bool G_OPT_UPGRADE      = false ;
bool G_OPT_EXTERN_EVENT = false ;
int  G_OPT_TEST_COUNT   = 10 ;
bool G_IS_STREAM_FULL   = false ;

class CSend : public CNDFThread
{
    private :
        CNDFHttp2Request *req_ ;

        void Initial(void) {} ;
        void Final  (void) {} ;
        void Run    (void) ;

    public :
        CSend() {} ;
        ~CSend() {} ;

        void  Set(CNDFHttp2Request *_req) { req_ = _req ; }
};

class CRecv : public CNDFThread
{
    private :
        CNDFHttp2Request *req_ ;

        void Initial(void) {} ;
        void Final  (void) {} ;
        void Run    (void) ;

    public :
        CRecv() {} ;
        ~CRecv() {} ;

        void  Set(CNDFHttp2Request *_req) { req_ = _req ; }
};

void CSend::
Run(void)
{
    NDF_ST_HTTP2_REQUEST  req ;
    int                   nSend = 0 ;
    int                   i ;
    int                   ret ;

    std::chrono::system_clock::time_point start = std::chrono::system_clock::now() ;
    std::chrono::duration<double>         duration ;

    req.payload_.data_ = (char *)malloc(G_HTTP2_OPTION.nMaxPayloadSize_) ;

    req.hdr_.push_back(std::make_pair("content-type","text")) ;

    printf("Send Thread Start...\n") ;


    std::chrono::system_clock::time_point req_start ;
    std::chrono::duration<double>         req_duration ;

    for(i=0;i<G_OPT_TEST_COUNT ;i++)
    {
        req.messageId_ = i ;
        req.authority_[0] = 0x00 ;
        strcpy (req.method_,   "POST") ;
        strcpy (req.path_     ,"/testing/http2/restful") ;
        sprintf(req.payload_.data_  ,"%08d",i+1) ;
        req.payload_.size_ = G_HTTP2_OPTION.nMaxPayloadSize_ ;

        req_start = std::chrono::system_clock::now() ; 
        for(;;)
        {
            ret = req_->Request(&req,false) ;
            switch(ret)
            {
                case NDF_HTTP2_ASYNC_REQUEST_CONN_CLOSE :
                    printf("connection closed...\n") ;
                    break ;
                case NDF_HTTP2_ASYNC_REQUEST_QUEUE_FULL :
                    usleep(1000) ;
                    break ;
                case NDF_HTTP2_ASYNC_REQUEST_STREAM_FULL :
                    G_IS_STREAM_FULL  = true ;
                    printf("stream-id full\n") ;
                    break ;
            }
            if ( ret == NDF_HTTP2_ASYNC_REQUEST_QUEUE_FULL ) 
            {
                req_duration = std::chrono::system_clock::now() - req_start ;
                if ( req_duration.count() < (double)1) 
                    continue ;
            }    
            break ;
        }
        if ( ret != NDF_HTTP2_ASYNC_REQUEST_SUCCESS ) 
        {
            if ( ret == NDF_HTTP2_ASYNC_REQUEST_QUEUE_FULL )
            {
                printf("queue full timeout...") ;
            }
            break ;
        }
/*
 * internal waiting
        if ( req_->Request(&req,true) != NDF_HTTP2_ASYNC_REQUEST_SUCCESS )
        {
            printf("request error!\n") ;
            break ;
        }
*/
        nSend++ ;

        if ( G_OPT_VERBOSE == true )
        {
        }
        else
        {
            if ( nSend % (G_OPT_TEST_COUNT/10) == 0)
            {
                printf("%d data sended...\n",nSend) ;
            }
        }
    }

    I_LOG("finished...") ;
    duration = std::chrono::system_clock::now() - start ;
    printf("%d elapsed...%lf... tps=%lf\n",i,duration.count(),(double)G_OPT_TEST_COUNT/duration.count()) ;
    
    free(req.payload_.data_) ;
}

void CRecv::
Run(void)
{
    NDF_ST_HTTP2_RESPONSE res ;
    int                   nRecv = 0 ;
    int                   rv ;

    std::chrono::system_clock::time_point start  = std::chrono::system_clock::now() ;
    std::chrono::duration<double>         duration ;
    bool first = false ;

    res.payload_.data_ = (char *)malloc(G_HTTP2_OPTION.nMaxPayloadSize_) ;

    printf("Receive Thread Start...\n") ; 
    for(;;)
    {
        if ((rv = req_->Response(&res)) == -1)
        {
            printf("Response Receive error!... state(%d)\n",req_->GetState()) ;
            printf("\t cause:%s\n",NDF_HTTP2_GET_ERROR_MSG(req_->GetStateCause())) ;
            break ;
        }
        if ( rv == 0 ) // no response
        {
            // printf("no response !\n") ;
            continue ;
        }

        if ( first == false )
        {
            start  = std::chrono::system_clock::now() ;
            first  = true ;
        }

        nRecv++ ;


        if ( atoi(res.rs_) == 0 )
        {
            // res.error_ = -9998 : response timeout
            // res.error_ = 0,1,...~  > server remove stream. see nghttp2.h RST_STREAM status codes
            // printf("message(%d) response error(%d)!\n",res.messageId_,res.error_) ;
            I_LOG("message(%d) response error(%d)!",res.messageId_,res.error_) ;

        }
        else
        { 
            if ( G_OPT_VERBOSE == true )
            {
                printf("%d response status:%s,value[%4d:%8.8s]\n",
                    nRecv,res.rs_,(int)res.payload_.size_,res.payload_.data_) ;
            }
            if ( G_OPT_TEST_COUNT > 1000 )
            {
                if ((nRecv % (G_OPT_TEST_COUNT/100)) == 0)
                {
                    duration = std::chrono::system_clock::now() - start ;
                    printf("%d response status:%s,value[%4d:%8.8s] tps=%lf\n",
                        nRecv,res.rs_,(int)res.payload_.size_,res.payload_.data_,
                        (double)nRecv/duration.count()) ;     
                }
            }
            if ( atoi(res.rs_) == 429 )
            {
                printf("Received Too many request Response....\n") ;
            }
        }

        if ( nRecv == G_OPT_TEST_COUNT ) 
        {
            duration = std::chrono::system_clock::now() - start ;
            printf("%d elapsed...%lf... tps=%lf\n",
                nRecv,duration.count(),(double)nRecv/duration.count()) ;
            break ;
        }

        if ( G_IS_STREAM_FULL == true &&  req_->IsComplete() == true )
        {
            printf("stream full stopped...\n") ;
            req_->SetState(NDF_HTTP2_CONN_STATE_CLOSE,NDF_HTTP2_CONN_CLOSE_CAUSE_STREAM_FULL) ;
            break ;
        }
    }

    free(res.payload_.data_) ;
    req_->Disconnect() ;
}

int doTest(void)
{
    CNDFHttp2Request req ;
    SSL_CTX         *ssl_ctx = 0 ;
    CSend            s ;
    CRecv            r ;

    if ( G_OPT_UPGRADE == false )
    {
        NDF_SSL_INIT() ;
        if ((ssl_ctx = NDF_SSL_CREATE_CLIENT_CTX(0,0,0)) == false ) 
            return false ;
        I_LOG("SSL init success...") ;
    }

    memset(&G_HTTP2_OPTION,0x00,sizeof(NDF_ST_HTTP2_OPTIONS)) ;
    G_HTTP2_OPTION.nMaxPayloadSize_ = 4096 ;
    G_HTTP2_OPTION.nMaxConcurrentStream_ = 1000 ;
    G_HTTP2_OPTION.nTimeout_ = 2 ;

    if ( req.Initialize("test",&G_HTTP2_OPTION) == false )
    {
        return false ;
    }

    if ( G_OPT_UPGRADE == true )
    {
        I_LOG("connect http/1.1 upgrade...") ;
        if (req.Connect(G_OPT_HOST,G_OPT_PORT,G_OPT_EXTERN_EVENT) == false )
        {
            return false ;
        }
    }
    else
    {
        I_LOG("connect http/2 direct...") ;
        if (req.Connect(G_OPT_HOST,G_OPT_PORT,ssl_ctx,G_OPT_EXTERN_EVENT) == false )
        {
            return false ;
        }
    }

    I_LOG("Testing %d Request!...",G_OPT_TEST_COUNT) ;

    // for testing stream-full
    //req.SetStreamID(2147473647) ;

    getchar();

    if ( G_OPT_EXTERN_EVENT == false )
    {
        r.Set(&req) ;
        s.Set(&req) ;

        r.Execute() ;
        sleep(1) ;
        s.Execute() ;

        pause() ;

        return true ;
    }
    else
    {
        printf("extern event - not support yet!...\n") ;
        return false ;
    }
}

void Help(char *_name)
{
    fprintf(stderr,"Invalid Arguments...\n") ;
    fprintf(stderr,"\t./%s -h host -p port [-u] [-v] [-c test-count]\n",_name) ;
    fprintf(stderr,"\t -h host  : host ip address\n") ;
    fprintf(stderr,"\t -p port  : host listening port\n") ;
    fprintf(stderr,"\t -u       : http/1/1 upgrade connect mode\n") ;
    fprintf(stderr,"\t -e       : external event dispath mode\n") ;
    fprintf(stderr,"\t -v       : verbose mode\n") ;
    fprintf(stderr,"\t -c count : test count\n") ;
    fprintf(stderr,"examples)\n\t%s -h 127.0.0.1 -p 8088 -u -v -c 10\n",_name) ;
}

bool ParseArg(int _argc,char **_argv)
{
    int  mode = -1 ;
    int  opt ;

    while((opt = getopt(_argc,_argv, "h:p:c:uve")) != -1)
    {
        switch(opt)
        {
            case 'h':
                mode = 0 ;
                if ( optarg ) strcpy(G_OPT_HOST,optarg) ;
                else mode = -1 ;
                break ;
            case 'p':
                mode = 0 ;
                if ( optarg ) G_OPT_PORT = atoi(optarg) ;
                else mode = -1 ;
                break ;
            case 'e':
                G_OPT_EXTERN_EVENT = true ;
                break ;
            case 'u':
                G_OPT_UPGRADE = true ;
                break ;
            case 'c':
                if ( !optarg ) mode = -1 ; else G_OPT_TEST_COUNT = atoi(optarg) ;
                break ;
            case 'v':
                G_OPT_VERBOSE = true ;
                break ;
            default :
                mode = -1 ;
                break ;
        }
    }

    if ( mode == -1 || G_OPT_PORT == 0 )
    {
        Help(_argv[0]) ;
        return false ;
    }

    return true ;
}


int main(int argc,char **argv)
{
    bool result ;

    if ( ParseArg(argc,argv) == false ) exit(0) ;

    NDF_OPEN_SERVICE_LOG(15) ;

    NDF_HTTP2_INIT() ;

    result = doTest() ;

    NDF_CLOSE_SERVICE_LOG() ;

    if ( result == true ) exit(0); else exit(1) ;
}
