#include "NDFCommonOpenSSL.hpp"
#include "CNDFThread.hpp"
#include "CNDFHttp2Request.hpp"
#include "NDFHttp2Option.hpp"
#include "NDFServiceLog.hpp"

NDF_ST_HTTP2_OPTIONS G_HTTP2_OPTION ;

char G_OPT_HOST[32] ;
int  G_OPT_PORT         = 0 ;
bool G_OPT_VERBOSE      = false ;
bool G_OPT_UPGRADE      = false ;
int  G_OPT_TEST_COUNT   = 10 ;

int doTestSync(CNDFHttp2Request *_req)
{
    NDF_ST_HTTP2_REQUEST  req ;
    NDF_ST_HTTP2_RESPONSE res ;
    int                   i ;
    int                   nRecv = 0 ;

    std::chrono::system_clock::time_point start = std::chrono::system_clock::now() ;
    std::chrono::duration<double>         duration ;

    req.payload_.data_ = (char *)malloc(G_HTTP2_OPTION.nMaxPayloadSize_) ;
    res.payload_.data_ = (char *)malloc(G_HTTP2_OPTION.nMaxPayloadSize_) ;

    req.hdr_.push_back(std::make_pair("content-type","text")) ;
    req.hdr_.push_back(std::make_pair("routing-host","127.0.0.1:8000")) ;

    for(i=0;i<G_OPT_TEST_COUNT ;i++)
    {
        req.messageId_ = i ;
        req.authority_[0] = 0x00 ;
        strcpy (req.method_,   "POST") ;
        strcpy (req.path_     ,"/testing/http2/restful") ;
        sprintf(req.payload_.data_  ,"%08d",i) ;
        req.payload_.size_ = G_HTTP2_OPTION.nMaxPayloadSize_ ;
        if ( _req->Request (&req,&res) == false )
        {
            printf("error!\n") ;
            break ;
        }

        nRecv++ ;

        if ( G_OPT_VERBOSE == true )
        {
            printf("%d response status:%s,value[%4d:%8.8s]\n",
                i,res.rs_,(int)res.payload_.size_,res.payload_.data_) ;
        }
        if ( G_OPT_TEST_COUNT > 1000 )
        {
            if ( (nRecv % (G_OPT_TEST_COUNT/100)) == 0)
            {
                duration = std::chrono::system_clock::now() - start ;
                printf("%d response status:%s,value[%4d:%8.8s] tps=%lf\n",
                    nRecv,res.rs_,(int)res.payload_.size_,res.payload_.data_,
                    (double)nRecv/duration.count()) ;
            }
        }
    }

    duration = std::chrono::system_clock::now() - start ;
    printf("%d elapsed...%lf... tps=%lf\n",i,duration.count(),(double)i/duration.count()) ;

    free(req.payload_.data_) ;
    free(res.payload_.data_) ;

    return true ;
}

int doTest(void)
{
    CNDFHttp2Request req ;
    SSL_CTX         *ssl_ctx = 0 ;

    if ( G_OPT_UPGRADE == false )
    {
        NDF_SSL_INIT() ;
        if ((ssl_ctx = NDF_SSL_CREATE_CLIENT_CTX(0,0,0)) == false ) 
            return false ;
        I_LOG("SSL init success...") ;
    }

    memset(&G_HTTP2_OPTION,0x00,sizeof(NDF_ST_HTTP2_OPTIONS)) ;
    G_HTTP2_OPTION.nMaxPayloadSize_ = 4096 ;
    G_HTTP2_OPTION.nTimeout_ = 1 ;

    if ( req.Initialize("test",&G_HTTP2_OPTION) == false )
    {
        return false ;
    }

    if ( G_OPT_UPGRADE == true )
    {
        I_LOG("connect http/1.1 upgrade...") ;
        if (req.Connect(G_OPT_HOST,G_OPT_PORT,false) == false )
        {
            return false ;
        }
    }
    else
    {
        I_LOG("connect http/2 direct...") ;
        if (req.Connect(G_OPT_HOST,G_OPT_PORT,ssl_ctx,false) == false )
        {
            return false ;
        }
    }

    I_LOG("Testing %d Request!...",G_OPT_TEST_COUNT) ;

    getchar();

    return doTestSync(&req) ;
}

void Help(char *_name)
{
    fprintf(stderr,"Invalid Arguments...\n") ;
    fprintf(stderr,"\t./%s -h host -p port [-u] [-v] [-c test-count]\n",_name) ;
    fprintf(stderr,"\t -h host  : host ip address\n") ;
    fprintf(stderr,"\t -p port  : host listening port\n") ;
    fprintf(stderr,"\t -u       : http/1/1 upgrade connect mode\n") ;
    fprintf(stderr,"\t -e       : external event dispath mode\n") ;
    fprintf(stderr,"\t -v       : verbose mode\n") ;
    fprintf(stderr,"\t -c count : test count\n") ;
    fprintf(stderr,"examples)\n\t%s -h 127.0.0.1 -p 8088 -u -v -c 10\n",_name) ;
}

bool ParseArg(int _argc,char **_argv)
{
    int  mode = -1 ;
    int  opt ;

    while((opt = getopt(_argc,_argv, "h:p:c:uv")) != -1)
    {
        switch(opt)
        {
            case 'h':
                mode = 0 ;
                if ( optarg ) strcpy(G_OPT_HOST,optarg) ;
                else mode = -1 ;
                break ;
            case 'p':
                mode = 0 ;
                if ( optarg ) G_OPT_PORT = atoi(optarg) ;
                else mode = -1 ;
                break ;
            case 'u':
                G_OPT_UPGRADE = true ;
                break ;
            case 'c':
                if ( !optarg ) mode = -1 ; else G_OPT_TEST_COUNT = atoi(optarg) ;
                break ;
            case 'v':
                G_OPT_VERBOSE = true ;
                break ;
            default :
                mode = -1 ;
                break ;
        }
    }

    if ( mode == -1 || G_OPT_PORT == 0 )
    {
        Help(_argv[0]) ;
        return false ;
    }

    return true ;
}


int main(int argc,char **argv)
{
    bool result ;

    if ( ParseArg(argc,argv) == false ) exit(0) ;

    NDF_OPEN_SERVICE_LOG(15) ;

    NDF_HTTP2_INIT() ;

    result = doTest() ;

    NDF_CLOSE_SERVICE_LOG() ;

    if ( result == true ) exit(0); else exit(1) ;
}
