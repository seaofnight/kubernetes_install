#include <sys/epoll.h>
#include "CNDFHttp2Listener.hpp"
#include "CNDFHttp2Response.hpp"
#include "NDFHttp2Option.hpp"
#include "NDFServiceLog.hpp"

NDF_ST_HTTP2_OPTIONS G_HTTP2_OPTION ;

int  G_OPT_PORT         = 0 ;
bool G_OPT_VERBOSE      = false ;
bool G_OPT_UPGRADE      = false ;

int doTestNoEvent(CNDFHttp2Response *_res)
{
    NDF_ST_HTTP2_REQUEST_RECV  req ;
    NDF_ST_HTTP2_RESPONSE      res ;
    int                        nRecv = 0 ;
    int                        ret ;

    res.payload_.data_ = (char *)malloc(G_HTTP2_OPTION.nMaxPayloadSize_) ;

    for(;;)
    {
        if (( ret = _res->Request(&req)) == -1 ) // error
        {
            break ;
        }
        else if ( ret == 0 )                     // no request
        {
            continue ;
        }
        else                                     // request exist
        {
            nRecv++ ;

            if ( G_OPT_VERBOSE == true )
            {
                printf("Recv Request...StreamId=%d value[%4d:%8.8s]\n",req.streamId_,(int)req.size_,req.data_) ;
                for(auto it = req.hdr_->begin();it != req.hdr_->end();it++)
                {
                    printf("\tHeader-info[%s-%s]\n",(*it).first.c_str(),(*it).second.c_str()) ;                
                }
            }
            else
            {
                if ((nRecv % 10000) == 0 )
                {
                    printf("%d request...value[%4d:%8.8s]\n",nRecv,(int)req.size_,req.data_) ;
                }
            }
            res.streamId_  = req.streamId_ ;
            strcpy(res.rs_,"200") ;
            sprintf(res.payload_.data_,"%8.8s",req.data_) ;
            res.payload_.size_ = G_HTTP2_OPTION.nMaxPayloadSize_ ;

            if ( _res->Response(&res,false) != NDF_HTTP2_RESPONSE_SUCCESS )
            {
                printf("Send error!\n") ;
                free(res.payload_.data_) ;
                return false ;
            }
        }
    }

    free(res.payload_.data_) ;

    return true ;
}

bool doTest(void)
{
    CNDFHttp2Listener  listener ;
    CNDFHttp2Response *res ;
    int                ret ;

    memset(&G_HTTP2_OPTION,0x00,sizeof(NDF_ST_HTTP2_OPTIONS)) ;
    G_HTTP2_OPTION.nMaxPayloadSize_ = 4096 ;

    if ( G_OPT_UPGRADE == false )
    {
        if ( listener.Initialize(AF_INET,G_OPT_PORT,&G_HTTP2_OPTION,false,
                 (char *)"./server.key",(char *)"./server.crt",0) == false )
        {
            return false ;
        }
    }
    else
    {
        if ( listener.Initialize(AF_INET,G_OPT_PORT,&G_HTTP2_OPTION,false) == false )
        {
            return false ;
        }

    }

    for(;;)
    {
        ret = listener.Accept(&res,1000) ;
        if ( ret == -1 ) // 1 sec waiting
        {
            return false ;
        }
        else if ( ret == 0 ) 
        {
            printf("no event...\n") ;
            continue ;
        }
        else break ;
    }

    return doTestNoEvent(res) ;
}

void Help(char *_name)
{
    fprintf(stderr,"Invalid Arguments...\n") ;
    fprintf(stderr,"\t./%s -p port [-u] [-v] [-c test-count]\n",_name) ;
    fprintf(stderr,"\t -p port  : host listening port\n") ;
    fprintf(stderr,"\t -u       : http/1/1 upgrade connect mode\n") ;
    fprintf(stderr,"\t -v       : verbose mode\n") ;
    fprintf(stderr,"examples)\n\t%s -p 8088 -u -v\n",_name) ;
}

bool ParseArg(int _argc,char **_argv)
{
    int  mode = -1 ;
    int  opt ;

    while((opt = getopt(_argc,_argv, "h:p:c:uve")) != -1)
    {
        switch(opt)
        {
            case 'p':
                mode = 0 ;
                if ( !optarg ) mode = -1 ; else G_OPT_PORT = atoi(optarg) ;
                break ;
            case 'u':
                G_OPT_UPGRADE = true ;
                break ;
            case 'v':
                G_OPT_VERBOSE = true ;
                break ;
            default :
                mode = -1 ;
                break ;
        }
    }

    if ( mode == -1 || G_OPT_PORT == 0 )
    {
        Help(_argv[0]) ;
        return false ;
    }

    return true ;
}

int main(int argc,char **argv)
{
    bool result ;

    if ( ParseArg(argc,argv) == false ) exit(0) ;

    NDF_OPEN_SERVICE_LOG(15) ;

    NDF_HTTP2_INIT() ;

    result = doTest() ;

    NDF_CLOSE_SERVICE_LOG() ;

    if ( result == true ) exit(0); else exit(1) ;
}
