#include "NDFServiceLog.hpp"
#include "CNDFHTTP2SRV.hpp"

class CMyApp
{
    private :
        NDF_HTTP2SRV_CALLBACKS callbacks_ ;

        bool OnConnect   (int32_t,const char *,const char *,int) ;
        void OnDisconnect(int32_t) ;
        void OnRequest   (int32_t _connId,NDF_ST_HTTP2_REQUEST_RECV *_req,NDF_ST_HTTP2_RESPONSE *_res) ;

    public  :
        CMyApp() ;
        ~CMyApp() {} ;

        NDF_HTTP2SRV_CALLBACKS *GetCallbacks(void) { return &callbacks_ ; }
};

CMyApp::
CMyApp(void)
{
    callbacks_.onConnect_    = std::bind(&CMyApp::OnConnect,
                                        std::ref(*this),
                                        std::placeholders::_1,
                                        std::placeholders::_2,
                                        std::placeholders::_3,
                                        std::placeholders::_4) ;

    callbacks_.onDisconnect_ = std::bind(&CMyApp::OnDisconnect,
                                        std::ref(*this),
                                        std::placeholders::_1) ;

    callbacks_.onRequest_    = std::bind(&CMyApp::OnRequest,
                                        std::ref(*this),
                                        std::placeholders::_1,
                                        std::placeholders::_2,
                                        std::placeholders::_3) ;

    callbacks_.onAsyncRequest_ = 0 ;
}

bool CMyApp::
OnConnect(int32_t _connId,const char *_scheme,const char *_ip,int _port)
{
    printf("Connect %d-(%s://%s:%d)\n",_connId,_scheme,_ip,_port) ;
    return true ;
}

void CMyApp::
OnDisconnect(int32_t _connId)
{
    printf("Disconnect %d\n",_connId) ;
}

void  CMyApp::
OnRequest(int32_t _connId,NDF_ST_HTTP2_REQUEST_RECV *_req,NDF_ST_HTTP2_RESPONSE *_res)
{
    printf("conn(%d) Receive Request %d\n",_connId,_req->streamId_) ;

    for(auto it = _req->hdr_->begin();it != _req->hdr_->end();it++)
    {
        printf("%s : %s\n",(*it).first.c_str(),(*it).second.c_str()) ;
    }
 
    _req->data_[ _req->size_] = 0 ;
    printf("Payload-Size[%lu]\n%s\n", _req->size_,_req->data_) ;


    strcpy(_res->rs_,"200") ;

    _res->payload_.size_ = _req->size_ ;
    memcpy(_res->payload_.data_,_req->data_,_req->size_) ;
}

bool DoTest(char *_cfg)
{
    CNDFHTTP2SRV srv ;
    CMyApp       app ;

    if ( srv.Initialize(_cfg,app.GetCallbacks()) == false )
    {
        return false ;
    }

    srv.Start() ;

    for(;;)
    {
        if ( srv.LoopOnce() == false ) break ;
    }

    return true ;
}

int main(int argc,char *argv[])
{
    NDF_OPEN_SERVICE_LOG(15) ;

    DoTest(argv[1]) ;

    NDF_CLOSE_SERVICE_LOG() ;
}
